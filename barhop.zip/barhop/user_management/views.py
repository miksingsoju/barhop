from django.contrib.auth import login, logout
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from .forms import RegistrationFormStep1, RegistrationFormStep2, ProfileUpdateForm
from .models import Profile
from bars.models import Bar

from django.contrib.auth import update_session_auth_hash

@login_required
def update_profile(request):
    user = request.user # This is your Profile instance
    form = ProfileUpdateForm(instance=user)
    my_bars = Bar.objects.filter(bar_owner=user) if user.user_type == "OWNER" else None
    
    if request.method == 'POST':
        # 1. Check for 'Edit Profile' submission
        if 'edit_profile' in request.POST:
            user.first_name = request.POST.get('first_name')
            user.last_name = request.POST.get('last_name')
            user.bio = request.POST.get('bio')
            if 'profile_image' in request.FILES:
                user.profile_image = request.FILES['profile_image']
            user.save()
            messages.success(request, "Display info updated!")

        # 2. Check for 'Personal Info' submission
        elif 'personal_info' in request.POST:
            form = ProfileUpdateForm(request.POST, instance=user)

            user.email = request.POST.get('email')

            user.save()
            messages.success(request, "Personal details updated!")

        # 3. Check for 'Change Password' submission
        elif 'change_password' in request.POST:
            old_pass = request.POST.get('old_password')
            new_pass = request.POST.get('new_password')

            # 1. Verify the old password matches the database
            if user.check_password(old_pass):
                if len(new_pass) >= 8: # Basic length check
                    # 2. Hash and save the new password
                    user.set_password(new_pass)
                    user.save()

                    # 3. Update session so they stay logged in
                    update_session_auth_hash(request, user)
                    messages.success(request, "Password changed successfully!")
                else:
                    messages.error(request, "New password is too short (min 8 chars).")
            else:
                messages.error(request, "The 'Old Password' you entered is incorrect.")

        return redirect('user_management:update_profile')
    else:
        form = ProfileUpdateForm(instance=user)

    return render(request, "registration/update_profile.html", {'form': form, "my_bars": my_bars })

@login_required
def delete_user(request):
    if request.method == 'POST':
        user = request.user
        # Log out first
        logout(request) 
        # Delete the User
        user.delete()   
        messages.success(request, "Your account has been successfully deleted.")
        return redirect('bars:bar-list') # Redirect to home
    
    # If they just visit the page (GET), show a confirmation page
    return render(request, 'registration/delete_confirm.html')


def check_existing_username(request):
    username = request.GET.get("username")
    user = Profile.objects.filter(username=username)
    if user:
        return HttpResponse(status=200)
    return HttpResponse(status=404)


def register_view(request):
    if request.user.is_authenticated:
        return redirect('bars:bar-list')

    if request.GET.get('reset') == '1':
        saved_email = request.session.get('registration_data', {}).get('email', '')
        request.session.pop('registration_data', None)
        request.session['back_email'] = saved_email
        return redirect('user_management:register')

    # Pick up saved email if coming from back button
    back_email = request.session.pop('back_email', '')

    # Get existing step 1 data from session
    reg_data = request.session.get('registration_data')

    if request.method == 'POST':
        if reg_data:
            form = RegistrationFormStep2(request.POST)
            print("Step 2 POST received")
            print("Form valid:", form.is_valid())
            print("Form errors:", form.errors)
            if form.is_valid():
                print("Creating user...")
                user = Profile.objects.create_user(
                    username=form.cleaned_data['username'],
                    email=reg_data['email'],
                    password=reg_data['password'],
                    first_name=form.cleaned_data['first_name'],
                    last_name=form.cleaned_data['last_name'],
                    date_of_birth=form.cleaned_data['date_of_birth'],
                    user_type=form.cleaned_data['user_type'] or Profile.UserType.BARHOPPER,
                )
                print("User created:", user)
                login(request, user, backend='user_management.backends.EmailBackend')
                request.session.pop('registration_data', None)
                print("Redirecting to bar-list")
                return redirect('bars:bar-list')
        else:
            form = RegistrationFormStep1(request.POST)
            if form.is_valid():
                request.session['registration_data'] = {
                    'email': form.cleaned_data['email'],
                    'password': form.cleaned_data['password_1'],
                }
                request.session.modified = True
                return redirect('user_management:register')
    else:
        form = RegistrationFormStep2() if reg_data else RegistrationFormStep1(initial={'email': back_email} if back_email else None)

    return render(request, 'registration/register.html', {
        'form': form,
        'step': 2 if reg_data else 1,
    })

