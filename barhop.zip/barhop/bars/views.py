from django.http import HttpResponse
from django.shortcuts import render, redirect
from .forms import CreateBarForm, UpdateBarImageFormSet
from .models import Bar, Amenity, BarImage  # , Address
from reservations.models import Seating
from user_management.models import Profile
from reservations.views import get_or_create_tables
from django.db.models import Case, When, Value, IntegerField
from django.contrib.auth.decorators import login_required


def bar_list(request):
    user_profile = request.user if request.user.is_authenticated else None
    bar_address = request.GET.get("bar_address")
    bar_name = request.GET.get("bar_name")
    custom_order = Case(
        When(bar_status='FIRE', then=Value(0)),
        When(bar_status='LUKEWARM', then=Value(1)),
        When(bar_status='COLD', then=Value(2)),
        output_field=IntegerField()
    )
    
    if bar_name:
        bars = Bar.objects.filter(bar_name__icontains=bar_name)
    elif bar_address:
        bars = Bar.objects.filter(bar_address__icontains=bar_address)
    else:
        bars = Bar.objects.all()

    bars.annotate(status_order=custom_order).order_by('status_order')
    
    # if user_profile != None and username == None:
    #         bars = Bar.objects.exclude(bar_owner=request.user).annotate(
    #             status_order=custom_order).order_by('status_order')


    return render(request, 'bars/bar-list.html', {
        'bars': bars,
    })

# @login_required
def create_bar(request):
    bar_form = CreateBarForm(request.POST or None, request.FILES or None)
    if not request.user.is_authenticated:
        return redirect('bars:bar-list')

    bar_user = request.user

    if bar_user.user_type != Profile.UserType.BAR_OWNER:
        return redirect('bars:bar-list')

    if request.method == "POST":
        if bar_form.is_valid():
            bar = bar_form.save(commit=False)
            bar.bar_owner = request.user
            bar.bar_draft = False
            bar.save()
            res = get_or_create_tables(request, bar=bar)

            if (res.status_code >= 400):
                return HttpResponse("error with creating tables", status_code=400)

            bar_form.save_m2m()

            images = request.FILES.getlist('images')
            for image_file in images:
                BarImage.objects.create(bar=bar, image=image_file)

            return redirect('bars:bar-details', bar_id=bar.id)
        else:
            print(bar_form.errors)
    else:
        bar_form = CreateBarForm()

    ctx = {
        "stepper": [
            {
                "num": "1",
                "title": "Bar Details",
                "desc": "Set up your bar's details.",
                "current": "current",
            },
            {
                "num": "2",
                "title": "Add Events",
                "desc": "What's happening at your bar? Let people know!",
                "current": "",
            },
            {
                "num": "3",
                "title": "Add Tables",
                "desc": "Set up your bar's reservation system.",
                "current": "",
            },
            {
                "num": "4",
                "title": "Publish Your Bar",
                "desc": "Share your bar with the world!",
                "current": "",
            }
        ],
        'bar_form': bar_form,
    }
    return render(request, 'bars/create-bar.html', ctx)
    

def bar_details(request, bar_id):
    bar_object = Bar.objects.get(id=bar_id)
    bar_owner = bar_object.bar_owner
    seating = Seating.objects.filter(bar=bar_object)
    
    return render(request, 'bars/bar-details.html', {
        'bar': bar_object,
        'bar_owner': bar_owner,
        'seating': seating,
    })


def bar_update(request, bar_id):
    bar_object = Bar.objects.get(id=bar_id)
    bar_images = BarImage.objects.filter(bar=bar_object)
    if bar_object.bar_owner != request.user:
        return redirect('bars:bar-details', bar_id=bar_id)
    if request.method == 'POST':
        bar_form = CreateBarForm(request.POST, request.FILES, instance=bar_object)
        if bar_form.is_valid():
            bar = bar_form.save()

            to_delete_ids = request.POST.getlist('delete_images')
            if to_delete_ids:
                BarImage.objects.filter(id__in=to_delete_ids, bar=bar_object).delete()

            images = request.FILES.getlist('images')
            for image_file in images:
                BarImage.objects.create(bar=bar, image=image_file)

            return redirect('bars:bar-details', bar_id=bar_id)
    else:
        bar_form = CreateBarForm(instance=bar_object)
        if bar_images:
            bar_image_formset = UpdateBarImageFormSet(queryset=bar_images)
    
    ctx = {
        "stepper": [
            {
                "num": "1",
                "title": "Bar Details",
                "desc": "Edit up your bar's details.",
                "current": "current",
            },
            {
                "num": "2",
                "title": "Publish Your Bar",
                "desc": "Share your bar with the world!",
                "current": "",
            }
        ],
        'bar_form': bar_form,
        'bar_image_formset': bar_image_formset if bar_images else None,
        'bar': bar_object,
    }

    return render(request, 'bars/update-bar.html', ctx)

